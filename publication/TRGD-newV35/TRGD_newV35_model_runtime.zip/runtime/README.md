# TRGD (V90) with latest V35 foreground

This runtime loads V35_310_best.pt parameters (fixed100-epoch binary training, validation-selected epoch32) as the binary detector. The V66 epoch37 and V90 epoch78 temporal/graph weights stay frozen. The inference sequence is new V35 root/background -> V66 temporal prior -> V90 ConvLSTM/GAT -> Axis constraint -> Junction constraint. Final foreground equals the new binary support. Only0=background,1=existing root,2=new root are exported; visible roots in the first observation form the existing baseline. Existing combines persistent and extension states.

For one registered common-field position, put T1_common_RGB.png etc and common_domain.png in one folder. Missing dates stay absent. Run:

python predict_series.py --rgb-dir /path/to/position --position position-ID --output /path/to/new/output

For folders named T1.png etc the same command works. The common-domain mask, when present, excludes separators and noncommon support. RGB remains on its supplied common grid. The script does not register or rescale RGB. Outputs are under predictions/position-ID. Missing periods are not synthesized, and comparison uses the previous observed date.

This uses the existing V90 pretrained transfer interface. Skeleton node partition/neighbors are reconstructed, a nearest-junction degree proxy supplies one geometric cue, and the unavailable original dense local-correction prepass is omitted. Therefore it is not an exact reconstruction of the original tensor-bound preprocessing. No temporal weights are trained in this update, and archived validation scores are not assigned to these new-field outputs. The original checkpoints remain preserved.
