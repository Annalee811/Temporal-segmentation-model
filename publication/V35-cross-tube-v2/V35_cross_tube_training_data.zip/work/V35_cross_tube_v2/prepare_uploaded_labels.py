import csv,hashlib,io,json,shutil,zipfile
from pathlib import Path
import numpy as np
from PIL import Image
root=Path('/workspace/Temporal-segmentation-model');out=root/'work/V35_cross_tube_v2';src=Path('/workspace/attachments/a7d398a6-ad9c-4c50-90bc-b1a164adc237/root_annotation_progress (25).json');z=zipfile.ZipFile('/workspace/shared/downloads/prediction_18_positions_500px_manual_edit.zip')
sha=lambda b:hashlib.sha256(b).hexdigest()
def writej(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
shutil.copy2(src,out/'uploaded_annotation.json');out.joinpath('data/RGB').mkdir(parents=True,exist_ok=True);out.joinpath('data/mask').mkdir(exist_ok=True)
a=json.loads(src.read_text());oldrows=list(csv.DictReader(open(root/'02_root_background/assets/data/manifest.csv',encoding='utf-8-sig')));rows=[]
for x in a['images']:
 name=x['name'];r=np.array(x['layers']['mask']);m=np.repeat(r[::2].astype('uint8'),r[1::2]).reshape(x['height'],x['width']);assert set(np.unique(m))<={0,128,255}
 b=z.read('RGB/'+name);assert sha(b)==x['image_sha256'];assert Image.open(io.BytesIO(b)).size==m.shape[::-1]
 p=x['annotation_provenance'];tube=p['tube'];split='val' if tube=='0353-3' else ('test' if tube in ['A017-3','Q1-1'] else 'train')
 c=np.array(Image.open(io.BytesIO(z.read('prediction_labels/'+name.replace('.png','_classes.png')))));old=np.where(c==255,128,np.where(c>0,255,0));changed=int((m!=old).sum());protected=0
 # Preserve the released original validation and test regions even during final refit.
 if p['position']=='0353-2-B3':
  for q in oldrows:
   if q['split']=='train' or q['period']!=p['period']:continue
   xx=max(0,int(q['x'])-p['x']);yy=max(0,int(q['y'])-p['y']);xe=min(500,int(q['x'])+int(q['width'])-p['x']);ye=min(500,int(q['y'])+int(q['height'])-p['y'])
   if xe>xx and ye>yy:m[yy:ye,xx:xe]=128
  protected=int((m==128).sum())
 (out/'data/RGB'/name).write_bytes(b);Image.fromarray(m).save(out/'data/mask'/name)
 rows.append(dict(image_id=name,position=p['position'],tube=tube,material=p['material'],period=p['period'],split=split,x=p['x'],y=p['y'],width=500,height=500,root_pixels=int((m==255).sum()),ignore_pixels=int((m==128).sum()),changed_from_prediction=changed,reviewed_flag=x.get('reviewed',False),RGB_sha256=sha(b),mask_sha256=sha((out/'data/mask'/name).read_bytes())))
with (out/'data/manifest.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
checkpoint=root/'02_root_background/assets/weights/unet/best_model.pt';(out/'weights').mkdir(exist_ok=True);shutil.copy2(checkpoint,out/'weights/V35_original_epoch77.pt')
writej(out/'data_audit.json',dict(annotation_SHA256=sha(src.read_bytes()),images=len(rows),positions=len({r['position'] for r in rows}),tubes=len({r['tube'] for r in rows}),modified_images=sum(r['changed_from_prediction']>0 for r in rows),changed_pixels=sum(r['changed_from_prediction'] for r in rows),source_reviewed_flags_all_false=True,authorization='User explicitly supplied this uploaded file as manual training labels; reviewed UI flags do not override that instruction.',label_mapping={'0':'background','255':'root (all temporal categories merged)','128':'ignore'},temporal_layers_used=False,split_counts={s:sum(r['split']==s for r in rows) for s in ['train','val','test']},original_checkpoint_SHA256=sha(checkpoint.read_bytes()),original_checkpoint_preserved='weights/V35_original_epoch77.pt',original_protected_pixels=sum(r['ignore_pixels'] for r in rows),new_label_reference='User-submitted edits of prediction-initialized masks; unchanged regions retain initialized predictions. Test metrics describe agreement with this supplied reference.'))
print(json.loads((out/'data_audit.json').read_text()))
