250 × 250 px microtube annotation sample

Open annotate_independent_250px.html in Chrome or Edge after extracting this ZIP.
All 8 RGB images are embedded and load automatically. No network is required.
The editor is adapted from the HTML supplied by the user.
Image pixels are native crops, with no contrast enhancement or rescaling.
T1 marks baseline roots. Subsequent observations use new root and existing root.
Existing root includes persistent roots and extensions. Uncertain pixels can be ignored.
The source's temporal layer is used internally. Exported *_classes.png maps use
0 background, 1 existing root, 2 new root, 4 T1 baseline, 255 ignore.
Use Save all progress JSON regularly. Each reviewed image can be exported as a ZIP.
Both microtubes have real T1, T2, T3 and T4 observations.
The set contains one field each from Q1-2 and 0353-1.
Q1-2-B3 uses the corrected canonical source release.
The sites differ from the archived development tube 0353-2.
Crops were selected visually for clearer roots after the user's correction.
This is a clarity-selected external annotation subset. Broader tube-level
generalization should use a prespecified representative sample.
Native coordinates and immutable source URLs/hashes are in selection_manifest.csv.
Source registration is automatic. Ambiguous temporal correspondences can be marked uncertain.
