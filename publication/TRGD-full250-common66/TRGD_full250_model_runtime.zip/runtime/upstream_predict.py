"""Full250 V35 selected epoch91 and frozen epoch37 V66 temporal priors for V90 deployment."""
import argparse,csv,hashlib,json,sys,time,importlib.util,os
from pathlib import Path
import numpy as np,torch
from PIL import Image
HERE=Path(__file__).resolve().parent
SRC=Path(os.environ.get('V90_UPSTREAM_SOURCE',str(HERE/'upstream_source') if (HERE/'upstream_source').exists() else '/workspace/work/materials_methods_20261103/sources/core'))
def loadfile(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
binary=loadfile('binary_models',SRC/'02_root_background/models.py')
sys.path.insert(0,str(SRC/'03_temporal_V66/core'))
import features
head=loadfile('temporal_model',SRC/'03_temporal_V66/core/model.py')
def root_predict(model, rgb, batch_size=8):
    h,w=rgb.shape[:2];ph,pw=max(h,250),max(w,250)
    im=np.pad(rgb,((0,ph-h),(0,pw-w),(0,0)),mode='edge')
    xs=sorted(set(list(range(0,pw-249,188))+[pw-250]))
    ys=sorted(set(list(range(0,ph-249,188))+[ph-250]))
    coords=[(x,y) for y in ys for x in xs]
    win=np.maximum(np.hanning(250)[:,None]*np.hanning(250)[None,:],.02).astype('float32')
    sm=np.zeros((ph,pw),np.float32);wg=np.zeros_like(sm);model.eval()
    with torch.inference_mode():
        for i in range(0,len(coords),batch_size):
            cc=coords[i:i+batch_size]
            x=torch.from_numpy(np.stack([im[y:y+250,x:x+250] for x,y in cc]).transpose(0,3,1,2).copy()).float().to(memory_format=torch.channels_last)/255
            for (x,y),p in zip(cc,model(x).sigmoid()[:,0].numpy()):
                sm[y:y+250,x:x+250]+=p*win;wg[y:y+250,x:x+250]+=win
    assert (wg>0).all()
    return (sm/wg)[:h,:w]

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--position');ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();torch.set_num_threads(4);torch.set_num_interop_threads(1)
 rows=list(csv.DictReader(open(os.environ.get('V90_INPUT_MANIFEST','/workspace/LI/dataset/current/active_images.csv'),encoding='utf-8-sig')));net=binary.RootUNet().to(memory_format=torch.channels_last);ck=HERE/'upstream/02_root_background/assets/weights/unet/best_model.pt';net.load_state_dict(torch.load(ck,weights_only=True,map_location='cpu')['state_dict']);net.eval();tn=head.TemporalHead();ck2=HERE/'upstream/03_temporal_V66/assets/weights/unet/best_temporal_head.pt';tn.load_state_dict(torch.load(ck2,weights_only=True,map_location='cpu')['state_dict']);tn.eval()
 for pos in dict.fromkeys(r['position_id'] for r in rows):
  if a.position and pos!=a.position:continue
  folder=a.output/pos;folder.mkdir(parents=True,exist_ok=True);previous=None
  for r in [r for r in rows if r['position_id']==pos]:
   t=r['period'];previous_period=previous[0] if previous else None;src=Path(os.environ.get('V90_RGB_ROOT','/workspace/work/all_series_RGB_PDF_20261105/sources'))/r['canonical_view_relative_path'];assert hashlib.sha256(src.read_bytes()).hexdigest()==r['registered_RGB_SHA256'];rgb=np.array(Image.open(src).convert('RGB'));tic=time.monotonic();ppath=folder/(t+'_binary_probability.npy')
   if ppath.exists():p=np.load(ppath)
   elif pos=='0353-2-B3' and os.environ.get('V90_USE_VERIFIED_B3_CACHE','1')=='1':
    p=np.load(HERE/f'upstream/03_temporal_V66/assets/frozen_binary/unet/upper/{t}_probability.npy');np.save(ppath,p)
   else:p=root_predict(net,rgb);np.save(ppath,p)
   domain_path=os.environ.get('V90_COMMON_DOMAIN')
   if domain_path:
    domain=np.array(Image.open(domain_path))>0
    assert domain.shape==p.shape
    p=np.where(domain,p,0).astype(np.float32);np.save(ppath,p)
   mask=p>=float(os.environ.get('V90_BINARY_THRESHOLD','0.5'));out=folder/(t+'_prior_probability.npz')
   if not out.exists():
    if previous is None:pr=np.full((3,*mask.shape),1/3,np.float32);cl=np.where(mask,4,0).astype(np.uint8)
    else:
     prev,prgb,prob,pmask=previous;f=features.features(prgb,rgb,prob,p,pmask,mask).astype(np.float16).astype(np.float32);pr=features.predict(tn,f,torch.device('cpu'),batch=4);cl=np.where(mask,pr.argmax(0)+1,0).astype(np.uint8);del f
    np.savez_compressed(out,probability=pr.astype(np.float16));Image.fromarray(cl).save(folder/(t+'_prior_classes.png'))
   Image.fromarray(mask.astype(np.uint8)*255).save(folder/(t+'_root_mask.png'));previous=(t,rgb,p,mask)
   (folder/(t+'_upstream_provenance.json')).write_text(json.dumps(dict(position_id=pos,period=t,previous_period=previous_period,binary_threshold=float(os.environ.get('V90_BINARY_THRESHOLD','0.5')),RGB_SHA256=r['registered_RGB_SHA256'],binary_epoch=91,binary_window=250,binary_stride=188,binary_training_epochs=100,temporal_epoch=37,review_required=r['review_required'],missing_dates_imputed=False),indent=2))
   print('UPSTREAM',pos,t,'seconds',round(time.monotonic()-tic,2),flush=True)
  (folder/'upstream_complete.json').write_text(json.dumps(dict(position=pos,periods=[r['period'] for r in rows if r['position_id']==pos])))
if __name__=='__main__':main()
