"""Two-root-class export for updated V35 + frozen V90 temporal inference."""
from pathlib import Path
import argparse,csv,json,hashlib,shutil
import numpy as np
from PIL import Image

def main(a):
 w=Path(a.work);prov=json.load(open(w/'adapter_provenance.json'));pos=prov['position'];out=Path(a.output)/pos;out.mkdir(parents=True,exist_ok=True);records=[];palette=np.array([[0,0,0],[55,118,185],[230,159,0]],dtype='uint8')
 for i,t in enumerate(prov['periods']):
  rgb=np.array(Image.open(w/'base/data/upper'/(t+'_RGB.png')).convert('RGB'));fg=np.array(Image.open(w/'base/v35_masks'/(t+'_root_mask.png')))>0;struct=np.array(Image.open(w/'junction/full'/(t+'_classes.png')));assert np.array_equal(struct>0,fg);cl=np.where(fg,np.where(struct==2,2,1),0).astype('uint8');assert np.isin(cl,[0,1,2]).all();assert i!=0 or not (cl==2).any();overlay=rgb.copy();overlay[fg]=(rgb[fg]*.25+palette[cl[fg]]*.75).astype('uint8');Image.fromarray(cl).save(out/(t+'_classes.png'));Image.fromarray(overlay).save(out/(t+'_root_temporal_overlay.png'));Image.fromarray(fg.astype('uint8')*255).save(out/(t+'_V35_root_mask.png'));shutil.copy2(w/'base/data/upper'/(t+'_RGB.png'),out/(t+'_common_RGB.png'));shutil.copy2(w/'junction/ownership'/(t+'_axis_owner.npz'),out/(t+'_axis_owner.npz'))
  records.append(dict(position=pos,period=t,previous_observed_period=prov['periods'][i-1] if i else '',existing_pixels=int((cl==1).sum()),new_pixels=int((cl==2).sum()),root_pixels=int(fg.sum()),foreground_added_pixels=0,foreground_removed_pixels=0,classes_SHA256=hashlib.sha256((out/(t+'_classes.png')).read_bytes()).hexdigest()))
 with (out/'temporal_summary.csv').open('w',newline='',encoding='utf-8-sig') as f:writer=csv.DictWriter(f,fieldnames=list(records[0]));writer.writeheader();writer.writerows(records)
 (out/'preprocessing_provenance.json').write_text(json.dumps({k:v for k,v in prov.items() if k not in ['accuracy_status','no_manual_labels']},indent=2)+'\n');print('TWO_CLASS_PREDICTIONS',out,flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--work',required=True);p.add_argument('--output',required=True);main(p.parse_args())
